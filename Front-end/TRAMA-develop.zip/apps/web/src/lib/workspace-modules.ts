/** Lista compartilhada entre a renderização do servidor e a interface do navegador. */
export const workspaceModules = [
  'Início',
  'Minhas vendas',
  'Meus produtos',
  'Indicadores',
  'Tendências',
  'Comparar mercado',
  'Relatórios',
  'Organização e equipe',
  'Configurações',
] as const;

export type WorkspaceModule = typeof workspaceModules[number];
