import { useState } from 'react';
import type { Route } from './+types/home';
import { seo } from '@/lib/seo';
import { banner } from '@/data/demo';
import { Institutional } from '@/home/institutional';
import { DemoEntry } from '@/home/demo-entry';
import { Workspace } from '@/home/workspace';
export function meta({matches,location}:Route.MetaArgs){return seo({matches,location},{title:'TRAMA — Gestão que conecta o Agreste',description:'Protótipo demonstrativo de gestão e inteligência comercial para confecções do Agreste pernambucano.',image:banner,jsonLd:{'@context':'https://schema.org','@type':'WebSite',name:'TRAMA',description:'Plataforma demonstrativa de gestão para a cadeia têxtil do Agreste.'}});}
export default function HomePage(){const [entry,setEntry]=useState(''),[profile,setProfile]=useState('');return profile?<Workspace profile={profile} exit={()=>setProfile('')}/>:<><Institutional enter={setEntry}/>{entry&&<DemoEntry mode={entry} close={()=>setEntry('')} start={p=>{setProfile(p);setEntry('');window.scrollTo(0,0);}}/>}</>;}


