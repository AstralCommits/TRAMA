package br.com.trama.auth;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/** Criação administrativa de usuário vinculado a uma confecção já cadastrada. */
public record AuthAdminRegisterRequest(
        @NotBlank @Size(max = 100) String nome,
        @NotBlank @Email @Size(max = 120) String email,
        @NotBlank @Size(min = 8, max = 72) String senha,
        @NotNull Long idConfeccao) {
}
