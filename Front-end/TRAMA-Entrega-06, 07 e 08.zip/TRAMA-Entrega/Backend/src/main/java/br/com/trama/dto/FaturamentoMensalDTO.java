package br.com.trama.dto;

import java.math.BigDecimal;

/** Total agregado por mês, exclusivamente dos lançamentos ativos. */
public record FaturamentoMensalDTO(String mes, Long quantidade, BigDecimal faturamento) {}
